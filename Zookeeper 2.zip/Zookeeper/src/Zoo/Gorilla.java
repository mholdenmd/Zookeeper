package Zoo;

public class Gorilla extends Mammal {
	public Gorilla(String nameInput) {
		super(nameInput);
	}
	public Integer strength = 5;
	public Integer heal = 10;
	public Integer move = 10;
	
	public void throwSomething(Mammal Booboo) {
		System.out.println("Kong threw Something");
		Booboo.energyLevel -= this.strength;		
	}
	public void eatBananas(Mammal eatFood) {
		System.out.println("Kong is eating bananas");
		eatFood.energyLevel += this.heal;
	
	}
	public void climb(Mammal move) {
		System.out.println("Kong is climbing");
		move.energyLevel -= this.move;
	}
	
}
//Create a separate class Gorilla that can throwSomething(), eatBananas(), and climb()
//
//● For the throwSomething() method, have it print out a message indicating that the gorilla has thrown something, as well as decrease the energy level by 5
//
//● For the eatBananas() method, have it print out a message indicating the gorilla's satisfaction and increase its energy by 10
//
//● For the climb() method, have it print out a message indicating the gorilla has climbed a tree and decrease its energy by 10
//
//● Create a GorillaTest class to instantiate a gorilla and have it throw three things, eat bananas twice, and climb once.