package Zoo;
import Zoo.Mammal;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla g1 = new Gorilla("Kong");
		Bat b1 = new Bat("Carl");
		
		b1.displayInfo();
		b1.attackTown(b1);
		b1.displayInfo();
		b1.eatHumans(b1);
		b1.attackTown(b1);
		b1.displayInfo();
		b1.attackTown(b1);
		b1.eatHumans(b1);
		b1.displayInfo();
		b1.fly(b1);
		b1.displayInfo();
		b1.fly(b1);
		b1.displayInfo();
		
		
		
	}

}
