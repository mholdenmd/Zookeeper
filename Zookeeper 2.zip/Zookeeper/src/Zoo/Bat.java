package Zoo;

public class Bat extends Mammal{
	public Bat(String nameInput) {
		super(nameInput);
		this.name = nameInput;
		this.energyLevel = 300;
	}
	public Integer fly = 50;
	public Integer eat = 25;
	public Integer attack = 100;
	
	public void fly(Mammal UpUp) {
		System.out.println(String.format("%s is flying", this.name));
		UpUp.energyLevel -= this.fly;		
	}
	public void eatHumans(Mammal bite) {
		System.out.println(String.format("%s is eating humans", this.name));
		bite.energyLevel += this.eat;		
	}
	public void attackTown(Mammal attackOnTown) {
		System.out.println(String.format("%s is attack a nearby town", this.name));
		attackOnTown.energyLevel -= this.attack;
	}
	
	
}

