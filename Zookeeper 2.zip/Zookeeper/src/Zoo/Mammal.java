package Zoo;

public class Mammal {

	protected String name;
	protected Integer energyLevel = 100;
	
	public Mammal(String nameInput) {
		this.name = nameInput;
	}
	public void displayInfo() {
		System.out.println(String.format("%s energy Level is: %s",this.name, this.energyLevel));
	}
	
}
